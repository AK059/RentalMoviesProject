﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using RentalMoviesProject;


namespace UnitTest
{
    [TestClass]
    public class UnitTest2
    {
        Database connection = new Database();
        [TestMethod]
        public void TestMethod1()
        {
            string Connection = connection.ConnectionString;
            Assert.AreEqual(@"Data Source=LAPTOP-59760NQF\SQLEXPRESS01; Initial Catalog=VBMOVIESFULLDATA.MDF;Integrated Security=True", Connection);
        }


    }
}
