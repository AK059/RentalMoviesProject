﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RentalMoviesProject;


namespace RentalMoviesProject
{
    [TestClass]
    public class UnitTest1
    {
        Database myDatabase = new Database();
        [TestMethod]
        public void TestMethod1()
        {
            string nameDatabase = myDatabase.DatabaseCheck();
            Assert.AreEqual(nameDatabase, "VBMOVIESFULLDATA.MDF");
        }

    }
}


    
